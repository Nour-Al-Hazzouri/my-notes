I'll convert the previous prop drilling example to use Context API, which will allow any component to access the user data directly without passing it through intermediate components:

```jsx
// First, create a context
import { createContext, useContext, useState } from 'react';

// Create the context
const UserContext = createContext();

// Create a provider component
function UserProvider({ children }) {
  const [userName, setUserName] = useState("John Doe");
  
  return (
    <UserContext.Provider value={{ userName, setUserName }}>
      {children}
    </UserContext.Provider>
  );
}

// Top level component - much cleaner now
function App() {
  return (
    <UserProvider>
      <div>
        <Header />
      </div>
    </UserProvider>
  );
}

// Header no longer needs to handle user data
function Header() {
  return (
    <div>
      <h1>My App</h1>
      <NavBar />
    </div>
  );
}

// NavBar is also simpler
function NavBar() {
  return (
    <nav>
      <UserProfile />
    </nav>
  );
}

// UserProfile can access the context directly
function UserProfile() {
  // Get data directly from context
  const { userName, setUserName } = useContext(UserContext);
  
  return (
    <div>
      <p>Welcome, {userName}!</p>
      <button onClick={() => setUserName("Jane Doe")}>
        Change User
      </button>
    </div>
  );
}
```

Key differences from the prop drilling version:
1. We create a context with `createContext()`
2. We wrap our app in a `UserProvider` that holds the state
3. `Header` and `NavBar` are simpler - no props to pass through
4. `UserProfile` gets data directly from context using `useContext`

The main benefits here are:
- Intermediate components (`Header` and `NavBar`) don't need to know about or pass down the user data
- Any component in the tree can access the user data by using `useContext(UserContext)`
- Adding new components that need user data doesn't require changing the props of components in between
---
To confirm each point:

1. Normal State Scope:
```jsx
function NormalComponent() {
  const [userName, setUserName] = useState("John");
  // Only accessible within this component and via props to children
}
```

2. Context API Parts:
```jsx
// Creates the context "container"
const UserContext = createContext();

// Defines what data should be shared
function UserProvider({ children }) {
  const [userName, setUserName] = useState("John");
  return (
    <UserContext.Provider value={{ userName, setUserName }}>
      {children}
    </UserContext.Provider>
  );
}

// Any component can now access the data
function AnyChildComponent() {
  const { userName, setUserName } = useContext(UserContext);
  // Can use userName and setUserName directly!
}
```

You can think of it like this:
- `createContext()` creates a special "channel"
- `UserProvider` is like a radio station that broadcasts the data
- `UserContext.Provider` is the actual transmitter
- `useContext` is like a radio receiver that any component can use to tune into that channel

The beauty is that components don't need to be direct children - they just need to be somewhere inside the `Provider` in the component tree to access the data.