# Using Keys Correctly in React List Components

## Introduction

This video tutorial demonstrates the proper usage of keys in React list components through a practical example of a simple todo list application for restaurant managers. The tutorial highlights common mistakes when implementing keys and provides solutions for correctly identifying list items regardless of their position.

## The Problem with Index-Based Keys

The tutorial begins with a React application that displays a warning in the browser console about missing unique keys for list items. The initial solution of using array indices as keys appears to resolve the warning, but testing reveals a critical issue:

When the order of todo items is reversed using a button click, the text inputs don't move with their associated data. This occurs because:

1. React uses keys to identify which elements have changed between renders
2. When using array indices as keys, the key remains the same even when the order changes
3. React preserves the internal state of components based on their keys
4. This causes a mismatch between the displayed data and the input state

```jsx
// Problematic implementation using index as key
{todos.map((todo, index) => (
  <ToDo key={index} id={todo.id} createdAt={todo.createdAt} />
))}
```

## The Solution: Using Unique Identifiers

The correct approach is to use a unique identifier from the data model itself:

```jsx
// Correct implementation using id as key
{todos.map((todo) => (
  <ToDo key={todo.id} id={todo.id} createdAt={todo.createdAt} />
))}
```

By using the `id` property as the key:
- Each todo item maintains its identity regardless of position
- When the order changes, React correctly moves the entire component with its state
- The text inputs now move with their associated data when reversed

## Code Implementation Details

The application consists of:

1. A `ToDo` component that renders a table row with:
   - An ID
   - An uncontrolled text input
   - A creation timestamp

2. An `App` component that:
   - Maintains a state array of todo objects with unique IDs
   - Provides a function to reverse the order of todos
   - Renders the list of todos and a reverse button

```jsx
function App() {
  const [todos, setTodos] = useState([{
    id: 'todo1',
    createdAt: '18:00',
  }, {
    id: 'todo2',
    createdAt: '20:30',
  }]);

  const reverseOrder = () => {
    // Reverse is a mutative operation, so we need to create a new array first.
    setTodos([...todos].reverse());
  }

  return (
    <div>
      <button onClick={reverseOrder}>Reverse</button>
      <table>
        <tbody>
          {todos.map((todo) => (
            <ToDo key={todo.id} id={todo.id} createdAt={todo.createdAt} />
          ))}
        </tbody>
      </table>
    </div>
  );
}
```

## Important React Principles Demonstrated

1. **Immutability in State Management**: The tutorial emphasizes creating a copy of the array before applying the mutative `reverse()` method to avoid directly modifying React state.

2. **React's Development Mode Warnings**: React provides helpful console warnings that identify potential issues in the application.

3. **Component State Preservation**: React preserves component state based on keys, which can lead to unexpected behavior if keys aren't chosen correctly.
