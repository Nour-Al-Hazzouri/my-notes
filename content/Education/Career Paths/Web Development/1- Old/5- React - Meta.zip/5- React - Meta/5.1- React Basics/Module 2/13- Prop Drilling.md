# Understanding Prop Drilling in React

## What is Prop Drilling?
* Props being passed through multiple layers of components
* Data flows from parent → child → grandchild and so on
* Each intermediate component must pass the prop even if it doesn't use it

## Code Example Overview

```jsx
// App Component - Where the data journey begins
function App() {
    return (
        <Main
            msg="I passed through the Header and the Wrapper and I reached the Button component"
        />
    );
}

// Main Component - First level
function Main(props) {
    // Passes msg to Header without using it
    return <Header msg={props.msg} />;
}

// Header Component - Second level
function Header(props) {
    return (
        <div style={{ border: "10px solid whitesmoke" }}>
            <h1>Header here</h1>
            {/* Passes msg to Wrapper without using it */}
            <Wrapper msg={props.msg} />
        </div>
    );
}

// Wrapper Component - Third level
function Wrapper(props) {
    return (
        <div style={{ border: "10px solid lightgray" }}>
            <h2>Wrapper here</h2>
            {/* Passes msg to Button without using it */}
            <Button msg={props.msg} />
        </div>
    );
}

// Button Component - Final destination
function Button(props) {
    return (
        <div style={{ border: "20px solid orange" }}>
            <h3>This is the Button component</h3>
            {/* Finally uses the msg prop */}
            <button onClick={() => alert(props.msg)}>Click me!</button>
        </div>
    );
}
```

## Data Flow Breakdown
* App → Creates the original message
* Main → Passes to Header
* Header → Passes to Wrapper
* Wrapper → Passes to Button
* Button → Finally uses the message in an alert

## Visual Structure
* Components are nested within each other
* Each has a distinct border to show boundaries:
  * Header: Whitesmoke border
  * Wrapper: Light gray border
  * Button: Orange border
* Main component doesn't have visual representation

## Key Observations
* Only the Button component actually uses the msg prop
* All intermediate components (Main, Header, Wrapper) just pass it through
* This creates unnecessary coupling between components
* As apps grow, this pattern becomes harder to maintain
* This example intentionally shows the problem in isolation
* Real applications would need better solutions (like Context API) for this pattern

## Why This Matters
* Demonstrates a common React anti-pattern
* Shows why more sophisticated state management might be needed
* Helps understand the need for solutions like:
  * React Context API
  * State management libraries
  * Component composition
  * Custom hooks