```jsx
// Top level component
function App() {
  const [userName, setUserName] = useState("John Doe");
  
  return (
    <div>
      <Header userName={userName} setUserName={setUserName} />
    </div>
  );
}

// Header component needs to pass the data down, even though it doesn't use it
function Header({ userName, setUserName }) {
  return (
    <div>
      <h1>My App</h1>
      <NavBar userName={userName} setUserName={setUserName} />
    </div>
  );
}

// NavBar also passes the data through without using it
function NavBar({ userName, setUserName }) {
  return (
    <nav>
      <UserProfile userName={userName} setUserName={setUserName} />
    </nav>
  );
}

// Finally, UserProfile actually uses the data
function UserProfile({ userName, setUserName }) {
  return (
    <div>
      <p>Welcome, {userName}!</p>
      <button onClick={() => setUserName("Jane Doe")}>
        Change User
      </button>
    </div>
  );
}
```

In this example:
1. `App` holds the state for `userName`
2. `Header` receives it but doesn't use it
3. `NavBar` receives it but doesn't use it
4. `UserProfile` finally uses the data to display the name and provide a button to change it

This demonstrates the "bucket brigade" problem - `Header` and `NavBar` are forced to accept and pass down props they don't actually use, just to get them to `UserProfile`. As your app grows, this can become increasingly complex and hard to maintain. 