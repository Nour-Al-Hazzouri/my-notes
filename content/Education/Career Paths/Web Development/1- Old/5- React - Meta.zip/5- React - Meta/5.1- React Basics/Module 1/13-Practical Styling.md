- Styling can be done inside of each component by declaring the object which will hold the style and using camelCase
- The values must be wrapped with " " 
- Each property must be separated with ,
- Example:
	![[Pasted image 20241227154829.png]]
	- The style should be applied to the elements in the component itself, not in the App.js