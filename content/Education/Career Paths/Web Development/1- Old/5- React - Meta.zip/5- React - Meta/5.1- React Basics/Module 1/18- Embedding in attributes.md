- You can embed a JSX expression in an attribute
	![[Pasted image 20241228101842.png]]