- Just like HTML, event are specified in the specific element but in camelCase, and are given a value of the function they trigger
- Example:
```jsx
function Event(){
	return (
		const eventHandler= ()=> console.log("Event Handled")
		<button onClick= {eventHandler}> Click me! </button>
	);
};
```