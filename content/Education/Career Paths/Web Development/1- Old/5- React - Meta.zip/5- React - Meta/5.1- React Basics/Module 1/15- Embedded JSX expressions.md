- Embedded expressions allow developers to insert the values of JS variables into HTML of React elements
Example:
```jsx
function formatName(firstName, surname){
	return firstName + " " + surname;
};
const fullName= <p>{ formatName("Wilson", "Williams") }</p>
//Then it can be inserted as:
{fullName};
```
